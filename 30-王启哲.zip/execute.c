#include "myshell.h"




int execute_shellcmd(SHELLCMD *t)
{
    int  exitstatus;
    FILE * stream;
    if(t == NULL) {			
	exitstatus	= EXIT_FAILURE;
    }
    else {				
    //对命令进行分类，参考函数print_shellcmd0()
    switch (t->type) {
    case CMD_COMMAND :
	//print_redirection(t);
	//file redirection; output and input; append or not append
	if(t->infile != NULL)
            printf("< %s ", t->infile);
        if(t->outfile != NULL) {
            if(t->append == false)
		stream = freopen(t->outfile, "w", stdout );
            else
		stream = freopen(t->outfile, "a", stdout );
        }

	exitstatus = shellcmd(t);
	if(NULL != stream)
	{
	    fclose(stdout);
	    freopen("/dev/tty","w",stdout);
	}
	break;

    case CMD_SEMICOLON :
        execute_shellcmd(t->left);
        execute_shellcmd(t->right);
	//print_shellcmd0(t->left); printf("; "); print_shellcmd0(t->right);
	break;

    case CMD_AND :
	exitstatus = execute_shellcmd(t->left);
	if (0 == exitstatus)
		exitstatus = execute_shellcmd(t->right);

	//print_shellcmd0(t->left); printf("&& "); print_shellcmd0(t->right);
	break;

    case CMD_OR :
	exitstatus = execute_shellcmd(t->left);
	if (0 != exitstatus)
		exitstatus = execute_shellcmd(t->right);
	//print_shellcmd0(t->left); printf("|| "); print_shellcmd0(t->right);
	break;

    case CMD_SUBSHELL :
	printf("( "); print_shellcmd0(t->left); printf(") ");
	print_redirection(t);
	break;

    case CMD_PIPE :
	execute_shellcmd(t->left);
	print_shellcmd0(t->left); printf("| "); print_shellcmd0(t->right);
	break;
	//background command execute
    case CMD_BACKGROUND :
        execute_shellcmd(t->left);

	if(daemon_init() == -1)
	{
	    printf("can't fork self\n");
    	    exit(0);
        }
        openlog("daemontest", LOG_PID, LOG_USER);
        syslog(LOG_INFO, "program started.");
        signal(SIGTERM, sig_term); // arrange to catch the signal
        while(1)
        {
            execute_shellcmd(t->right);
        }

	//print_shellcmd0(t->left); printf("& "); print_shellcmd0(t->right);
	break;

    default :
	fprintf(stderr, "%s: invalid CMDTYPE in print_shellcmd0()\n", argv0);
	exit(EXIT_FAILURE);
	break;
    }

	//exitstatus	= EXIT_SUCCESS;
    }

    return exitstatus;
}

//单独执行一个命令
int shellcmd(SHELLCMD * t)
{
    int  exitstatus = EXIT_SUCCESS;

    if ( !strcmp(t->argv[0],"quit") || !strcmp(t->argv[0],"exit"))
    {
	fprintf(stderr,"Exit MyShell, Goodbye!\n\n");
        exit (0);
    }
    else if(!strcmp(t->argv[0],"ls"))
	my_ls(t->argc,t->argv);
    else if(!strcmp(t->argv[0],"time"))
	my_time();
    else if(t->argv[0][0] == '/')
	execv(t->argv[0],t->argv);
    else if(!strcmp(t->argv[0],"cd"))
	my_cd(t->argc,t->argv);
    else if(!strcmp(t->argv[0],"mkdir"))
        my_mkdir(t->argc,t->argv);
    else if(!strcmp(t->argv[0],"rmdir"))
        my_rmdir(t->argc,t->argv);
    else if(!strcmp(t->argv[0],"pwd"))
        my_pwd();
    else if(!strcmp(t->argv[0],"find"))
        my_find();
    else if(!strcmp(t->argv[0],"rename"))
        my_rename();
    else if(!strcmp(t->argv[0],"cat"))
	my_cat(t->argc,t->argv);
    
        
    else
	{fprintf(stderr, "%s: command not fount!\n", t->argv[0]);
	exitstatus = EXIT_FAILURE;}
    return exitstatus;

}

//列出文件列表
int my_ls(int argc , char ** argv)
{

    DIR *dirptr = NULL;
    struct dirent *entry;
    char dirpath[100];
    if(argc<2)
        strcpy(dirpath ,".");
    else
        strcpy(dirpath, argv[1]);
    if(argc>2)
    {
        printf("the program can only deal with one dir at once\n");
        return 1;
    }
    if((dirptr = opendir(dirpath)) == NULL)
    {
        printf("open dir error !\n");
        return 1;
    }
    else
    {
        while (entry = readdir(dirptr))
        {
        printf("%s ", entry->d_name);
        }
    printf("\n");
    closedir(dirptr);
    }
}

//打印路径
void my_pwd()
{
     char *path=NULL;
     path=getcwd(NULL,0);
     puts(path);
     free(path);
}

//创建目录
void my_mkdir(int argc,char **argv)
{
	//char command1[30];
	//scanf("%s",command1);
    //fflush(stdin);
    //if(mkdir(command1,0755)!=0)
    //printf("make dir default!\n");
	char dirpath[30];
	strcpy(dirpath,argv[1]);
	if(mkdir(dirpath,0755)!=0)
	{
		printf("default");
	}
}

//删除目录
void my_rmdir(int argc,char **argv)
{
	//char command2[30];
	//scanf("%s",command2);
    //fflush(stdin);
    //if(rmdir(command2)!=0)
    //printf("delete dir default!\n");
	char dirpath[30];
	strcpy(dirpath,argv[1]);
	if(rmdir(dirpath)!=0)
	printf("default");
}
//寻找文件
void my_find()
{
	char *path1;
    char str1[30],str2[30];
    struct dirent *re;
	int j=0;
	DIR *dir;
	scanf("%s",str1);
    fflush(stdin);
    scanf("%s",str2);
    fflush(stdin);
    if((dir=opendir(str1))==NULL)
       printf("open dir error!\n");
    while((re=readdir(dir))!=NULL)
    {
       if(strcmp(re->d_name,str2)==0)
        {
         chdir(str1);
         path1=getcwd(NULL,0);
         puts(path1);
         chdir("..");
         j=1;
        }
     }
     if(j==0)
     {
     printf("no the file!\n");
     }
}



//改变路径
int my_cd(int argc, char ** argv)
{
        int dirptr;
        char dirpath[100];
        if (argv[1] == NULL)
                strcpy(dirpath, "/tmp");
        else
                strcpy(dirpath, argv[1]);
        dirptr = chdir(dirpath);

        return 0;
}

//时间
int my_time()
{
    struct  timeval    tv;
    gettimeofday(&tv,NULL);

    printf("tv_sec:%d\n",tv.tv_sec);
    printf("tv_usec:%d\n",tv.tv_usec);
    return 0;
}

void my_cat(int argc,char *argv[])
{
	FILE *fp = fopen(argv[1],"r");
	int read_ret;
	if(argc<2)
	{
	printf("please input source file!\n");
	}
	if(fp == NULL)
	{
	printf("open source %s failed!\n",argv[1]);
	return -1;
	}
	while(1)
	{
	read_ret = fgetc(fp);
	if(feof(fp))
	{
	printf("read file %s end\n",argv[1]);
	break;
	}
	fputc(read_ret,stdout);
	}
}

//重命名一个文件或目录
void my_rename()
{
	char newname[30],oldname[30];
	 printf("pleace input the old name:");
     scanf("%s",oldname);
     fflush(stdin);
     printf("pleace input the new name:");
     scanf("%s",newname);
     fflush(stdin);
     if(rename(oldname,newname)!=0)
     {
       printf("change name default!");
     }
}

//复制一个已存在的文件

//返回界面
int daemon_init(void)
{
    pid_t pid;
    if((pid = fork()) < 0)
        return(-1);
    else if(pid != 0)
        exit(0); 
    setsid();
    chdir("/");
    umask(0);
    close(0);
    close(1);
    close(2);
    return(0);
}
//返回情报信息
void sig_term(int signo)
{
    if(signo == SIGTERM)
    // catched signal sent by kill(1) command
    {
        syslog(LOG_INFO, "program terminated.");
        closelog();
        exit(0);
    }
}

